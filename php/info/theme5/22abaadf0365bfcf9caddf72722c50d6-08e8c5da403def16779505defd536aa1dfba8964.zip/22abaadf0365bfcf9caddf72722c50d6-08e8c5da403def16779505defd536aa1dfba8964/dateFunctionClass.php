<?
class DateFunctionsClass{
	private $date1 = '';
	private $date2 = '';

	/**
     * установка первой даты
     */
	public function setDate1($date1)
	{
		
	}

    /**
     * установка второй даты
     */
	public function setDate2($date2)
	{
		
	}

    /**
     * дата в формате '2020-02-02' преобразовуется в timestamp
     * @param $date
     * @return int
     */
    public function getDateInTimestamp($date = ''):int
    {

    }

    /**
     * получение разницы двух дат
     * @param $date1
     * @param $date2
     * @return int
     */
	public function getDifferentDate($date1 = '', $date2 = ''):int
	{

	}

    /**
     * определение является ли дата рабочим днем
     * @param $date
     * @return bool
     */
	public function isWorkDate($date = ''):bool
    {

    }

    /**
     * функция возвращает словами день недели
     * @param string $date
     * @return string
     */
    public function getNameDayOfWeek($date = ''): string
    {

    }


}