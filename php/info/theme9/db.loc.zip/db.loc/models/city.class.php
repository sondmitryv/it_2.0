<?php

require_once($_SERVER['DOCUMENT_ROOT'].'/models/db.class.php');

Class City extends db
{
	public $table_name = 'city';

	
}



